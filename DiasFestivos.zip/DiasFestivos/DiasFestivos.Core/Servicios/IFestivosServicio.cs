﻿using DiasFestivos.Dominio.Entidades;
using DiasFestivos.Dominio.DTOs;

namespace DiasFestivos.Core.Servicios
{
    public interface IFestivosServicio
    {
        Task<IEnumerable<Festivo>> ObtenerTodos();

        Task<Festivo> Obtener(int Id);

        Task<IEnumerable<Festivo>> Buscar(string Dato);

        Task<Festivo> Agregar(Festivo Festivo);

        Task<Festivo> Modificar(Festivo Festivo);

        Task<bool> Eliminar(int Id);


        Task<IEnumerable<FechaFestivo>> ObtenerAño(int Año);

        Task<bool> EsFestivo(DateTime Fecha);
    }
}
