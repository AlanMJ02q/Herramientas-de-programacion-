﻿using DiasFestivos.Dominio.Entidades;

namespace DiasFestivos.Core.Servicios
{
    public interface ITipoServicioBase
    {

        Task<Tipo> Agregar(Tipo Tipo);

        Task<IEnumerable<Tipo>> Buscar(string Dato);

        Task<bool> Eliminar(int Id);

        Task<Tipo> Modificar(Tipo Tipo);

        Task<Tipo> Obtener(int Id);
        Task<IEnumerable<Tipo>> ObtenerTodos();
    }
}