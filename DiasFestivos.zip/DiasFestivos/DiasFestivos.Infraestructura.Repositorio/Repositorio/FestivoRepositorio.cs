﻿using DiasFestivos.Core.Repositorios;
using DiasFestivos.Dominio.Entidades;
using DiasFestivos.Infraestructura.Repositorio.Contextos;
using Microsoft.EntityFrameworkCore;

namespace DiasFestivos.Infraestructura.Repositorio.Repositorio
{
    
        public class FestivoRepositorio : IFestivoRepositorio
        {
            private FestivosContexto context;

            public FestivoRepositorio(FestivosContexto context)
            {
                this.context = context;
            }

            public async Task<Festivo> Obtener(int Id)
            {
                return (Festivo)(await context.Festivos
                    .Include(item => item.Tipo) 
                    .FirstOrDefaultAsync(item => item.Id == Id));
            }

            public async Task<IEnumerable<Festivo>> ObtenerTodos()
            {
                return await context.Festivos
                    .Include(item => item.Tipo) 
                    .ToListAsync();
            }

            public async Task<IEnumerable<Festivo>> Buscar(string Dato)
            {
                return await context.Festivos
                                       .Where(item => item.Nombre.Contains(Dato)) 
                                       .Include(item => item.Tipo) 
                                       .ToListAsync(); 
            }

            public async Task<Festivo> Agregar(Festivo Festivo)
            {
                context.Festivos.Add(Festivo);
                await context.SaveChangesAsync();
                return Festivo;
            }
            public async Task<Festivo> Modificar(Festivo Festivo)
            {
                var FestivoExistente = await context.Festivos.FindAsync(Festivo.Id);
                if (FestivoExistente == null)
                {
                    return null;
                }
                context.Entry(FestivoExistente).CurrentValues.SetValues(Festivo);
                await context.SaveChangesAsync();
                return (Festivo)(await context.Festivos.FindAsync(Festivo.Id));
            }

            public async Task<bool> Eliminar(int Id)
            {
                var FestivoExistente = await context.Festivos.FindAsync(Id);
                if (FestivoExistente == null)
                {
                    return false;
                }

                context.Festivos.Remove(FestivoExistente);
                await context.SaveChangesAsync();
                return true;
            }
        }
}
