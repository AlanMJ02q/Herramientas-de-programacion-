﻿namespace DiasFestivos.Dominio.DTOs
{
    public class FechaFestivo
    {
        public DateTime Fecha { get; set; }
        public string Nombre { get; set; }
    }
}
