﻿using DiasFestivos.Core.Repositorios;
using DiasFestivos.Core.Servicios;
using DiasFestivos.Infraestructura.Repositorio.Contextos;
using DiasFestivos.Infraestructura.Repositorio;
using DiasFestivos.aplication.Servicios;
using DiasFestivos.Core.Repositorios;
using DiasFestivos.Infraestructura.Repositorio.Contextos;
using DiasFestivos.Infraestructura.Repositorio.Repositorio;
using Microsoft.EntityFrameworkCore;

namespace apiFestivos.Presentacion.InyeccionDependencias
{
    public static class InyeccionDependencias
    {

        public static IServiceCollection AgregarDependencias(this IServiceCollection servicios, IConfiguration configuracion)
        {
            //Agregar el DBContext
            servicios.AddDbContext<FestivosContexto>(opcionesConstruccion =>
            {
                opcionesConstruccion.UseSqlServer(configuracion.GetConnectionString("Festivos"));
            });

            //Agregar los repositorios
            servicios.AddTransient<ITipoRepositorio, TipoRepositorio>();
            servicios.AddTransient<IFestivoRepositorio, FestivoRepositorio>();


            //Agregar los servicios
            servicios.AddTransient<ITipoServicio, ITipoServicio>();
            servicios.AddTransient<IFestivosServicio, FestivoServicio>();

            servicios.AddSingleton<IConfiguration>(configuracion);

            return servicios;
        }
    }

}
