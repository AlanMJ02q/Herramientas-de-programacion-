﻿using DiasFestivos.Dominio.Entidades;

namespace DiasFestivos.Core.Repositorios
{
    public class ITipoRepositorio
    {
        Task<IEnumerable<Tipo>> ObtenerTodos();

        Task<Tipo> Obtener(int Id);

        Task<IEnumerable<Tipo>> Buscar(string Dato);

        Task<Tipo> Agregar(Tipo Tipo);

        Task<Tipo> Modificar(Tipo Tipo);

        Task<bool> Eliminar(int Id);

    }
}
